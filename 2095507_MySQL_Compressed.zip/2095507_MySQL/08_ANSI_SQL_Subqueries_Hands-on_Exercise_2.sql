USE University_Management_System;

SELECT  si.Reg_Number,si.student_name, sm.marks, sm.subject_code 				-- Exercise 1
FROM student_info AS si INNER JOIN Student_Marks AS sm
ON si.Reg_Number = sm.Reg_Number
WHERE sm.Reg_Number 
IN (SELECT Reg_Number FROM student_marks) 
ORDER BY sm.Marks DESC LIMIT 1;

SELECT si.Reg_Number , si.Student_Name, sm.Subject_code,sm.Marks 				-- Exercise 2
FROM Student_Marks AS sm INNER JOIN Student_Info AS si 
ON si.reg_number = sm.reg_number
WHERE sm.Reg_Number 
IN (SELECT reg_number FROM student_marks 
	GROUP BY subject_code HAVING MAX(marks))
    AND subject_code = 'EI05IP';
    
SELECT si.Reg_Number , si.Student_Name, sm.Subject_code,sm.Marks 				-- Exercise 3
FROM Student_Marks AS sm INNER JOIN Student_Info AS si 
ON si.reg_number = sm.reg_number
WHERE sm.Reg_Number 
IN (SELECT reg_number FROM student_marks 
	GROUP BY subject_code HAVING MAX(marks))
    AND subject_code = 'EI05IP';
    
SELECT Student_Name, Reg_Number FROM Student_Info 											-- Exercise 4
WHERE reg_number IN (SELECT Reg_Number FROM Student_Marks WHERE Subject_Code = 'EI05IP'
ORDER BY Marks DESC) LIMIT 1 OFFSET 1;


