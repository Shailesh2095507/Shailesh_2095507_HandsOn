USE University_Management_System;

CREATE VIEW STUDENT_GPA_emp_id AS								-- Exercise 1
SELECT si.Student_Name, sr.Reg_Number, sr.Semester, sr.GPA 
FROM Student_Result AS sr INNER JOIN Student_Info AS si 
ON si.Reg_Number = sr.Reg_Number; 
SELECT * FROM STUDENT_GPA_emp_id;

SELECT * FROM STUDENT_GPA_emp_id											-- Exercise 2
WHERE GPA > 5 ORDER BY GPA DESC;

CREATE VIEW STUDENT_AVERAGE_GPA_emp_id AS									-- Exercise 3 
SELECT si.Student_Name, sr.Reg_Number, ROUND(avg(GPA),2) AS Average_GPA 
FROM Student_Result AS sr INNER JOIN Student_Info AS si 
ON si.Reg_Number = sr.Reg_Number GROUP BY reg_number;
select * from student_average_gpa_emp_id;

SELECT * FROM Student_Average_GPA_emp_id 
WHERE Average_GPA>7;														-- Exercise 4

CREATE INDEX Index_1 
ON Student_Marks(Semester);													-- Exercise 5

ALTER TABLE Student_Marks 
DROP INDEX Index_1 ;

CREATE UNIQUE INDEX Index_Email 											-- Exercise 6
ON Student_Info(Email_Id);


