USE University_Management_System;  				-- Exercise 1 Operators 2

SELECT * FROM Student_Info   		-- P 1
WHERE Email_Id IS NOT NULL;

SELECT Reg_Number, Marks FROM Student_Marks   		-- P 2
WHERE Marks>=70;

SELECT si.Reg_Number, si.Student_Name, sm.Subject_Code, sm.Semester, sm.Marks, smt.Subject_Name   -- P 3
FROM Student_Info AS si INNER JOIN Student_Marks AS sm ON si.Reg_Number = sm.Reg_Number
INNER JOIN Subject_Master AS smt ON smt.Subject_Code = sm.Subject_Code;

SELECT si.Reg_Number, si.Student_Name, sm.Subject_Code, sm.Semester, sm.Marks, smt.Subject_Name		-- P 4
FROM Student_Info AS si INNER JOIN Student_Marks AS sm ON si.Reg_Number = sm.Reg_Number
INNER JOIN Subject_Master AS smt ON smt.Subject_Code = sm.Subject_Code
WHERE sm.Marks>70;

SELECT * FROM Student_Result			-- P 5
ORDER BY Is_Eligible_Scholarship DESC; 

SELECT si.Reg_Number, si.Student_Name, sm.Subject_Code, sm.Semester, sm.Marks,  	-- P 6
smt.Weightage AS "Weightage_Marks = sm.Marks * smt.Weightage / 100" 
FROM Student_Info AS si INNER JOIN Student_Marks AS sm ON si.Reg_Number = sm.Reg_Number
INNER JOIN Subject_Master AS smt ON smt.Subject_Code = sm.Subject_Code;

SELECT Student_Name, Reg_Number FROM Student_Info			-- P 7
WHERE Student_Name LIKE 'M%';

SELECT si.Reg_Number, si.Student_Name, sm.Subject_Code, sm.Semester, sm.Marks, si.Email_Id			   -- P 8
FROM Student_Info AS si INNER JOIN Student_Marks AS sm ON si.Reg_Number = sm.Reg_Number
WHERE Email_Id IS NOT NULL;

SELECT si.Reg_Number, si.Student_Name, sm.Marks 			  		 -- P 9
FROM Student_Info AS si INNER JOIN Student_Marks AS sm ON si.Reg_Number = sm.Reg_Number
WHERE sm.Marks BETWEEN 60 AND 100;

SELECT si.Reg_Number, si.Student_Name, sm.Marks 			  		 -- P 10
FROM Student_Info AS si INNER JOIN Student_Marks AS sm ON si.Reg_Number = sm.Reg_Number
WHERE si.Student_Name NOT LIKE 'J%';

SELECT si.Reg_Number, si.Student_Name, sm.Marks, sm.subject_Code  			  		 -- P 11
FROM Student_Info AS si INNER JOIN Student_Marks AS sm ON si.Reg_Number = sm.Reg_Number
WHERE sm.Subject_Code NOT LIKE 'EE01DCF' AND sm.Subject_Code NOT LIKE 'EC02MUP';

SELECT * FROM Student_Info											-- P 12
WHERE Student_Name LIKE '%on';
