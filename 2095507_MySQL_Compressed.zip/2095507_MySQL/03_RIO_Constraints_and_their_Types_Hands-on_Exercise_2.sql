CREATE DATABASE USM;                              /* Exercise 3.1 */
USE USM;
CREATE TABLE Student_Info
(
	Reg_Number Varchar(20) PRIMARY KEY,
    Student_Name Varchar(30) not null,
	Branch Varchar(30),
	Contact_Number Varchar(25),
	Date_of_Birth Date,
	Date_of_Joining Date
);

CREATE TABLE Subject_Master
(
	Subject_Code varchar(20) PRIMARY KEY,
	Subject_Name Varchar(50) not null,
	Weightage float not null
);

CREATE TABLE Student_Marks
(
	Reg_Number Varchar(20),
    CONSTRAINT fk_Reg_Number1
    FOREIGN KEY (Reg_Number) REFERENCES Student_Info(Reg_Number),
	Subject_Code varchar(20),
    CONSTRAINT fk_Subject_Code1
    FOREIGN KEY (Subject_Code) REFERENCES Subject_Master(Subject_Code),
	Semester int not null,
	Marks int DEFAULT 0
);

CREATE TABLE Student_Result
(
	Reg_Number Varchar(20),
    CONSTRAINT fk_Reg_Number2
    FOREIGN KEY (Reg_Number) REFERENCES Student_Info(Reg_Number),
    Semester int not null,
	GPA float not null,
	Is_Eligible_Scholarship char(5) DEFAULT 'Yes'
);

ALTER TABLE Subject_Master
ADD constraint uq_Subject_Name UNIQUE (Subject_Name);
ALTER TABLE Student_Info
ADD constraint uq_Contact_Number UNIQUE (Contact_Number);
ALTER TABLE Student_Marks
ADD constraint uq_Marks Check(Marks<=100);
ALTER TABLE Student_Result
ADD constraint uq_GPA Check(GPA<=10);
ALTER TABLE Student_Result
ADD constraint uq_Is_Eligible_Scholarship Check(GPA>=7);
ALTER TABLE Student_Info
ADD constraint uq_Date_of_Birth Check(Date_of_Birth<Date_of_Joining);