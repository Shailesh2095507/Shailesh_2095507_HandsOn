USE University_management_System;

SELECT si.Reg_number, si.Student_name, sr.GPA					-- P 1 
FROM Student_Info AS si INNER JOIN Student_result AS sr
WHERE si.Reg_Number = sr.Reg_Number
ORDER BY sr.GPA DESC;

SELECT * FROM Student_info					-- P 2
ORDER BY  Student_Name;

ALTER TABLE Student_Info
ADD COLUMN Age Int;

UPDATE Student_Info
SET Age = 22 WHERE Reg_Number = '1BI17EI031';
UPDATE Student_Info
SET Age = 23 WHERE Reg_Number = '1BI17EI032';
UPDATE Student_Info
SET Age = 21 WHERE Reg_Number = 'BEC111402';
UPDATE Student_Info
SET Age = 20 WHERE Reg_Number = 'BEEI101204';
UPDATE Student_Info
SET Age = 28 WHERE Reg_Number = 'MB111305';
UPDATE Student_Info
SET Age = 24 WHERE Reg_Number = 'MC101301';

SELECT * FROM Student_Info							-- P 3 
ORDER BY AGE; 

SELECT si.Reg_number, si.Student_name, sr. Semester, sr.GPA					-- P 4 
FROM Student_Info AS si INNER JOIN Student_result AS sr
WHERE si.Reg_Number = sr.Reg_Number
ORDER BY sr.Semester,GPA DESC;

SELECT si.Reg_number, si.Student_name, sr. Semester, sr.GPA, sr.Is_Eligible_Scholarship					-- P 5 
FROM Student_Info AS si INNER JOIN Student_result AS sr
WHERE si.Reg_Number = sr.Reg_Number
ORDER BY sr.GPA DESC;

SELECT si.Reg_number, si.Student_name, sr. Semester, sr.GPA, sr.Is_Eligible_Scholarship					-- P 6 
FROM Student_Info AS si INNER JOIN Student_result AS sr
WHERE si.Reg_Number = sr.Reg_Number
ORDER BY sr.GPA DESC;

SELECT si.Reg_number, si.Student_Name, si.Branch, si.Date_of_Birth, si.Date_of_Joining, sr.Semester, 		-- P 7
MAX(sr.GPA) AS GPA1 
FROM Student_Info AS si INNER JOIN Student_result AS sr
WHERE si.Reg_Number = sr.Reg_Number
GROUP BY semester; 

SELECT si.Reg_number, si.Student_Name, si.Branch, si.Date_of_Birth, si.Date_of_Joining, sr.Semester, 		-- P 8
MIN(sr.GPA) AS GPA1 
FROM Student_Info AS si INNER JOIN Student_result AS sr
WHERE si.Reg_Number = sr.Reg_Number
GROUP BY semester; 