USE Operators;

SELECT Module_Id,Start_Date,						-- P 1
count(Associate_Id) AS Enrolled_Count
FROM Associate_Status 
GROUP BY Start_Date ORDER BY Enrolled_Count DESC;

SELECT ass.Module_Id,ass.Start_Date,tf.Trainer_Id,						-- P 2
count(Associate_Id) AS Enrolled_Count
FROM Associate_Status AS ass INNER JOIN Trainer_Feedback AS tf
WHERE Trainer_Id = 'F001'
GROUP BY Start_Date ORDER BY Enrolled_Count DESC;

SELECT ass.Module_Id,ass.Start_Date,tf.Trainer_Id,						-- P 3
count(Associate_Id)>2 AS Enrolled_Count
FROM Associate_Status AS ass INNER JOIN Trainer_Feedback AS tf
WHERE Trainer_Id = 'F001'
GROUP BY Start_date ORDER BY Enrolled_Count DESC;

SELECT Module_Id, Module_Name, Module_Duration 				-- P 4
FROM Module_info
ORDER BY (Module_Duration);

SELECT ai.Associate_ID, ai.Salutation, ai.Associate_Name, asi.Module_Id, mi.Module_Name, mi.Module_BaseFees			-- P 5
FROM Associate_info AS ai INNER JOIN Associate_Status AS asi
ON ai.associate_id = asi.associate_id 
INNER JOIN Module_info AS mi   
ON asi.Module_Id = mi.Module_Id
ORDER BY mi.Module_BaseFees DESC;

	