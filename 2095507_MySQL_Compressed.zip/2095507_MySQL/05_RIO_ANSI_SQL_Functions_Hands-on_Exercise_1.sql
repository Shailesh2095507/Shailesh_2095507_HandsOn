USE Operators ;

ALTER TABLE Module_Info
ADD COLUMN Module_InfraFees float;

SELECT * FROM Module_Info;

UPDATE Module_Info
SET Module_InfraFees = 123.452 WHERE Module_Id = 'ANDRD4';
SELECT * FROM Module_Info;

UPDATE Module_Info
SET Module_InfraFees = 223.452 WHERE Module_Id = 'DOTNT4';
UPDATE Module_Info
SET Module_InfraFees = 323.452 WHERE Module_Id = 'EM001';
UPDATE Module_Info
SET Module_InfraFees = 323.452 WHERE Module_Id = 'EM002';
UPDATE Module_Info
SET Module_InfraFees = 423.452 WHERE Module_Id = 'EM003';
UPDATE Module_Info
SET Module_InfraFees = 523.452 WHERE Module_Id = 'EM004';
UPDATE Module_Info
SET Module_InfraFees = 623.452 WHERE Module_Id = 'EM005';
UPDATE Module_Info
SET Module_InfraFees = 723.452 WHERE Module_Id = 'J2EE';
UPDATE Module_Info
SET Module_InfraFees = 823.452 WHERE Module_Id = 'J2SE';
UPDATE Module_Info
SET Module_InfraFees = 923.452 WHERE Module_Id = 'JAVAFX';
UPDATE Module_Info
SET Module_InfraFees = 923.452 WHERE Module_Id = 'MSBI08';
UPDATE Module_Info
SET Module_InfraFees = 913.452 WHERE Module_Id = 'O10PLSQL';
UPDATE Module_Info
SET Module_InfraFees = 903.452 WHERE Module_Id = 'O10SQL';
UPDATE Module_Info
SET Module_InfraFees = 903.452 WHERE Module_Id = 'SHRPNT';
UPDATE Module_Info
SET Module_InfraFees = 803.452 WHERE Module_Id = 'SQL2008';
UPDATE Module_Info
SET Module_InfraFees = 893.452 WHERE Module_Id = 'TM001';
UPDATE Module_Info
SET Module_InfraFees = 883.452 WHERE Module_Id = 'TM002';
UPDATE Module_Info
SET Module_InfraFees = 793.452 WHERE Module_Id = 'TM003';

SELECT Module_Id, Module_Name, Module_InfraFees,			-- P 1
ROUND(Module_InfraFees,2) AS Rounded_Fees 
FROM Module_Info;

SELECT Module_Id, Module_name,								-- P 2
UPPER(Module_Name) AS CAP_Module_Name
FROM Module_Info
WHERE BINARY Module_name <> BINARY UPPER(Module_Name);

INSERT INTO Module_Info
VALUES 
	('TM004','Physics',9,654.5647); 
		
INSERT INTO Module_Info						
VALUES 
	('TM005','artificial intelligence',7,674.5647),
    ('TM006','machine learning',9,974.5647);
SELECT * FROM Module_Info;

SELECT Module_Id, Module_name,
UPPER(Module_Name) AS CAP_Module_Name
FROM Module_Info
WHERE BINARY Module_name <> BINARY UPPER(Module_Name);

ALTER TABLE Module_Info										-- P 3
ADD COLUMN Module_Star_Date DATE;
ALTER TABLE Module_Info
ADD COLUMN Todays_Date DATE;

UPDATE Module_Info
SET Module_Star_Date = '2021-09-23' WHERE Module_Id = 'DOTNT4';
UPDATE Module_Info
SET Module_Star_Date = '2021-10-23' WHERE Module_Id = 'EM001';
UPDATE Module_Info
SET Todays_Date = curdate() WHERE Module_Id = 'DOTNT4';
UPDATE Module_Info
SET Todays_Date = Curdate() WHERE Module_Id = 'EM001';

SELECT Module_Id, Module_Name, Module_Star_Date, Todays_date,
DATEDIFF(Todays_Date,Module_Star_Date) AS Days_consumed
FROM Module_info;

SELECT Module_Id, Module_Name,							-- P 4
CONCAT(Module_Name,Module_Id) AS MODULE FROM Module_Info;

SELECT *,												-- P 5
UPPER(Module_Name) AS UP_Module_Name FROM Module_Info;	

SELECT *,												-- P 6
SUBSTRING(Module_Name,1,3) AS BTW_1AND3 FROM Module_Info;

ALTER TABLE Module_Info									-- P 7
ADD COLUMN Module_BaseFees Float DEFAULT 0;

SELECT * FROM Module_Info;

UPDATE Module_Info
SET Module_BaseFees = 22.52 WHERE Module_Id = 'DOTNT4';
UPDATE Module_Info
SET Module_BaseFees = 33.42 WHERE Module_Id = 'EM001';
UPDATE Module_Info
SET Module_BaseFees = 23.99 WHERE Module_Id = 'EM002';
UPDATE Module_Info
SET Module_BaseFees = 43.52 WHERE Module_Id = 'EM003';
UPDATE Module_Info
SET Module_BaseFees = 52.52 WHERE Module_Id = 'EM004';
UPDATE Module_Info
SET Module_BaseFees = 62.42 WHERE Module_Id = 'EM005';
UPDATE Module_Info
SET Module_BaseFees = 72.45 WHERE Module_Id = 'J2EE';
UPDATE Module_Info
SET Module_BaseFees = 82.42 WHERE Module_Id = 'J2SE';
UPDATE Module_Info
SET Module_BaseFees = 92.42 WHERE Module_Id = 'JAVAFX';
UPDATE Module_Info
SET Module_BaseFees = 23.52 WHERE Module_Id = 'MSBI08';
UPDATE Module_Info
SET Module_BaseFees = 13.42 WHERE Module_Id = 'O10PLSQL';
UPDATE Module_Info
SET Module_BaseFees = 03.42 WHERE Module_Id = 'O10SQL';
UPDATE Module_Info
SET Module_BaseFees = 03.45 WHERE Module_Id = 'SHRPNT';
UPDATE Module_Info
SET Module_BaseFees = 0 WHERE Module_Id = 'SQL2008';
UPDATE Module_Info
SET Module_BaseFees = 93.42 WHERE Module_Id = 'TM001';
UPDATE Module_Info
SET Module_BaseFees = 83.45 WHERE Module_Id = 'TM002';
UPDATE Module_Info
SET Module_BaseFees = 93.45 WHERE Module_Id = 'TM003';
UPDATE Module_Info
SET Module_BaseFees = 89.45 WHERE Module_Id = 'ANDRD4';

SELECT AVG(Module_BaseFees) AS Avg_Module_BaseFees FROM Module_Info;			-- P 7 Main_Code

SELECT *,
Trainer_Id+100 From Trainer_Info;

SELECT * ,																	-- P 8
CONCAT('F',(SUBSTRING(Trainer_Id,2,4)+100000)) AS Number
FROM Trainer_info;

ALTER TABLE Module_Info
MODIFY COLUMN Module_BaseFees varchar(15);

SELECT *,										-- P 9
CONCAT('The Base Fees Amount for the module name ',(SUBSTRING(Module_Name,1,25)),' is ',(SUBSTRING(Module_BaseFees,1,25))) AS Sentence-- 'is', (SUBSTRING(Module_BaseFees,1,8))) AS Sentence
FROM Module_Info;

SELECT COUNT(Module_Id) AS Total_Count				-- P 10 
FROM Module_Info;

SELECT SUM(Module_BaseFees) AS Sum_BaseFees				-- P 11 
FROM Module_Info;

SELECT MIN(Module_BaseFees) AS Min_BaseFees	  			-- P 12 
FROM Module_Info;

SELECT MAX(Module_BaseFees) AS Max_BaseFees
FROM Module_Info;


