CREATE DATABASE Cons;                            /* Exercise 3.1 */
USE Cons;
CREATE TABLE Trainer_Info
(
	Trainer_Id varchar(20) not null PRIMARY KEY check (Trainer_Id like'F%'),
    Salutation varchar(7) not null,
    Trainer_Name varchar(30) not null,
    Trainer_Loaction varchar(30) not null,
    Trainer_Track varchar(15) not null,
    Trainer_Qualification varchar(100) not null,
    Trainer_Experience int,
    Trainer_Email varchar(100) not null,
    Trainer_Password varchar(20) not null
);
SELECT * FROM Trainer_Info;

CREATE TABLE Batch_Info
(
	Batch_Id varchar(20) not null PRIMARY KEY check (Batch_Id like'B%'),
    Batch_Owner varchar(30) not null,
    Batch_BU_Name varchar(30) not null
);

CREATE TABLE Module_Info
(
	Module_Id varchar(20) not null PRIMARY KEY, 
    Module_Name varchar(40) not null,
    Module_Duration int not null
);
UPDATE Module_Info
SET Module_Id = UPPER(Module_Id);

CREATE TABLE Associate_Info
(
	Associate_Id varchar(20) not null PRIMARY KEY check (Associate_Id like'A%'),
    Salutation varchar(7) not null,
    Associate_Name varchar(30) not null,
    Associate_Loaction varchar(30) not null,
    Associate_Track varchar(15) not null,
    Associate_Qualification varchar(200) not null,
    Associate_Email varchar(100) not null,
    Associate_Password varchar(20) not null
);

CREATE TABLE Questions
(
	Question_Id varchar(20) not null check (Question_Id like'Q%'), 
    PRIMARY KEY(Question_Id),
    Module_Id varchar(20),
    FOREIGN KEY (Module_Id) REFERENCES Module_Info(Module_Id),
    Question_Text varchar(900) not null
);

CREATE TABLE Associate_Status
(
	Associate_Id varchar(20) not null,
    FOREIGN KEY (Associate_Id) REFERENCES Associate_Info(Associate_Id),
    Module_Id varchar(20) not null,
    FOREIGN KEY (Module_Id) REFERENCES Module_Info(Module_Id),
    Batch_Id varchar(20) not null,
    FOREIGN KEY (Batch_Id) REFERENCES Batch_Info(Batch_Id),
    Trainer_Id varchar(20) not null,
    FOREIGN KEY (Trainer_Id) REFERENCES Trainer_Info(Trainer_Id),
    Start_Date date,
    End_Date date,
    AFeedbackGiven varchar(20),
    TFeedbackGiven varchar(20)
);

CREATE TABLE Trainer_Feedback
(
	Trainer_Id varchar(20) not null,
    FOREIGN KEY (Trainer_Id) REFERENCES Trainer_Info(Trainer_Id),
    Question_Id varchar(20) not null,
    FOREIGN KEY (Question_Id) REFERENCES Questions(Question_Id),
    Batch_Id varchar(20) not null,
    FOREIGN KEY (Batch_Id) REFERENCES Batch_Info(Batch_Id),
    Module_Id varchar(20) not null,
    FOREIGN KEY (Module_Id) REFERENCES Module_Info(Module_Id),
    Trainer_Rating int not null
);

CREATE TABLE Associate_Feedback
(
	Associate_Id varchar(20) not null,
    FOREIGN KEY (Associate_Id) REFERENCES Associate_Info(Associate_Id),
    Question_Id varchar(20) not null,
    FOREIGN KEY (Question_Id) REFERENCES Questions(Question_Id),
    Module_Id varchar(20) not null,
    FOREIGN KEY (Module_Id) REFERENCES Module_Info(Module_Id),
    Associate_Rating int not null
);

CREATE TABLE Product						/* Exercise 3.2*/
(
	Product_ID int PRIMARY KEY,
    Product_Name varchar(50),
    Product_Price int
);
CREATE TABLE User_
(
	User_ID varchar(15) PRIMARY KEY,
    Product_ID int,
    CONSTRAINT fk_us_product_id
    FOREIGN KEY (Product_ID) REFERENCES Product(Product_ID),
    User_Name varchar(20)
);

INSERT INTO Product(Product_ID, Product_Name, Product_Price)
VALUES 
	(1,'A Dongle',290),
	(2,'B Dongle',1250);
INSERT INTO Product(Product_ID, Product_Name)
VALUES (3,'C Dongle');

SELECT * FROM Product;

ALTER TABLE User_ DROP FOREIGN KEY fk_us_product_id;

INSERT INTO User_(User_ID, Product_ID, User_Name)
VALUES ('U001',1,'Ramesh'),('U002',11,'Mahesh');
SELECT * FROM User_;