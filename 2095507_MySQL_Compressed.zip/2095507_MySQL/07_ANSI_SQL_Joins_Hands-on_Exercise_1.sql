USE Operators;													-- Exercise 1
SELECT ti.Trainer_Id, bi.Batch_Id FROM Trainer_Info AS ti
CROSS JOIN batch_Info AS bi;

SELECT Associate_Id, Module_Id, Start_Date, End_Date, Batch_ID, Batch_Owner, Batch_BU_Name		-- Exercise 2
FROM Associate_status AS ass INNER JOIN Batch_Info AS bi
WHERE ass.Batch_Id = bi.Batch_Id;

SELECT ass.Associate_Id , ti.Trainer_Id 				-- Exercise 3
FROM Associate_Status AS ass
RIGHT OUTER JOIN Trainer_Info AS ti 
ON ass.Trainer_Id = ti.Trainer_Id;

SELECT ass.Associate_Id , ti.Trainer_Id 				-- Exercise 4
FROM Associate_Status AS ass
LEFT OUTER JOIN Trainer_Info AS ti 
ON ass.Trainer_Id = ti.Trainer_Id;

ALTER TABLE associate_status							-- Exercise 5
ADD COLUMN Trainer_id varchar(20);
ALTER TABLE associate_status
ADD COLUMN Batch_id varchar(20);

SELECT * FROM Associate_Status;

SELECT ass.associate_id, ti.trainer_id 
FROM trainer_info AS ti LEFT OUTER JOIN associate_status AS ass 
ON ass.Trainer_Id = ti.trainer_id
UNION 
SELECT ass.associate_id, ti.trainer_id 
FROM trainer_info AS ti RIGHT OUTER JOIN associate_status AS ass 
ON ass.Trainer_Id = ti.trainer_id;

DELETE FROM associate_status 
WHERE Trainer_Id IS NULL;

ALTER TABLE  associate_status 
MODIFY Trainer_Id varchar(20) NOT NULL;

